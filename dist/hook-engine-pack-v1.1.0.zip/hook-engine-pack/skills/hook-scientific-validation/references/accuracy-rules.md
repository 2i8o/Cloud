# Scientific accuracy rules and claim registry

Applies to every hook, script line, overlay, caption and thumbnail. Entries marked **verified** were read in this project on 2026-10-20 through search-tool page excerpts (full pages may add caveats - re-open before publishing). Registry = *allowed wording*, not a substitute for professional review.

## A. Core rules (restated from the skill)
1. Verify before any definitive hook. 2. Separate evidence / interpretation / speculation. 3. No exaggerated risk. 4. No behaviour -> disease causal claim without evidence. 5. No misleading before/after. 6. Screening observation != diagnosis. 7. Preserve a standard's meaning and scope. 8. Optometry != Ophthalmology. 9. Flag claims for professional review. 10. Cite. 11. Reject what cannot be substantiated. 12. Compel through overlooked facts, useful demos, or unexpected explanations - never fear.

## B. Optometry vs ophthalmology (do not blur)
| | Ophthalmologist | Optometrist | Optician |
|---|---|---|---|
| Training (AAO description, S36) | MD/DO; medical school + residency; surgery | OD; 4 yrs optometry school after college; "not a medical doctor" in AAO's wording | technician fitting eyewear |
| Typical role (S36, S37) | diagnoses/treats all eye disease; eye surgery | primary vision care, exams, lens prescription, detection of abnormalities; medication prescribing "in some states" | verifies/fits lenses, frames; no vision testing or Rx |
Notes: AOA frames doctors of optometry as primary eye-health care providers who "examine, diagnose, treat and manage" eye disorders (S37). The professional bodies **disagree** on scope and training equivalence (S36, S38 vs S37). Hooks must not adjudicate this dispute. Scope in Iraq = **unverified**; ask the creator for the locally correct role description.

## C. Claim registry (allowed wording)

| ID | Topic | Allowed wording | Source / status |
|---|---|---|---|
| C01 | Screens and retinal damage | "According to the AAO, so far the evidence shows no meaningful link between blue light (from screens) and damage to human retinas or AMD." | S32 (2025-12-05), S33 verified. Lab/animal blue-light damage studies did not mimic screen exposure (S32). Overexposure to sunlight blue/UV can raise risk (S32). |
| C02 | Long-term unknowns | "Potential long-term cumulative effects are unknown" (2023 review) | S34 verified. Do not say "100% safe". |
| C03 | Blue-light glasses | "AAO doesn't recommend special blue-light glasses for computer use; several studies suggest no improvement in eye-strain symptoms." / "A 2023 review found no consistent evidence of benefit for eye strain or disease prevention." | S33, S34 verified. Do not say "useless/scam". |
| C04 | Why eyes feel tired at screens | "Discomfort is linked to reduced blinking and how devices are used, not to blue light, per AAO." Numbers: "about 15 blinks/min normally; AAO text cites 5-7/min at screens in one page and 'cut in half' in another" | S32 verified; use the softer "roughly halved or more" unless the exact AAO line is re-opened. |
| C05 | 20-20-20 | "AAO recommends: every 20 minutes look at something 20 feet (6 m) away for 20 seconds." | S33 verified as a recommendation; efficacy evidence **not reviewed** here -> do not say "proven". |
| C06 | Do glasses weaken eyes? | "AAO: using glasses won't worsen your vision or lead to eye disease." Also: wrong prescription won't damage the eyes but may cause strain/headache. | S35 myths 14-15 verified. Do not extend to children's myopia-control lenses (C09) - those intentionally alter progression. |
| C07 | 20/20 | "20/20 is the normal reference, not perfect; some people see 20/15." "Top number = your testing distance, bottom = distance at which a person with normal sight reads that line." | S44 verified. "About 35% of adults have 20/20 uncorrected; ~75% corrected" is one clinician's US estimate -> attribute; do not apply to Iraq. |
| C08 | Snellen geometry | "At 6/6 (20/20) the critical stroke of a letter subtends 1 arcminute; the whole letter 5 arcminutes." | S47 verified. |
| C09 | Myopia-control spectacle lenses | "A 2025 meta-analysis of 23 RCTs (13,315 children/adolescents) found specialty lenses slowed progression vs single-vision on average: AL -0.15 mm, SER -0.31 D; effect depends on design." | S39 verified (abstract). Not a cure; individual response varies; clinical advice needed. |
| C10 | Outdoor time and myopia | "A 2024 meta-analysis of 7 RCTs (9,437 children, all conducted in China) found more outdoor time lowered myopia incidence (RR 0.84) and slowed refractive shift." Effect on already-myopic children: mixed (S41). | S40 verified abstract; S41 verified excerpt. UV/sun-safety caveat applies. |
| C11 | Under/over-correction in myopia | "Trials found under-correcting glasses doesn't slow myopia progression and may speed it." | S41 verified (review excerpt). |
| C12 | Eye exercises | "AAO: eye exercises will not improve or preserve vision or reduce the need for glasses; exception - convergence insufficiency." | S35 myth 5 verified. |
| C13 | Pinhole | "A small aperture (~1 mm; clinical occluders use about 1.2 mm) reduces the blur circle, so blurred text can look sharper when the blur is refractive. Holes below ~0.75 mm cause diffraction blur; the view is darker and narrower; it does not rescue high errors (> ~5 D) and may not help - or may worsen - vision in macular disease or lens opacities. In clinic, improvement through a pinhole is a clue that blur is refractive, not a diagnosis; a home demo is illustrative." | S45, S46, S64, S65, S66, S67, S68 verified. NEVER state a size like "pin-sized" (a pin tip is smaller than the working range); for the demo say "about 1 mm (punch with a hole punch/needle then widen)". Do not tell viewers what their own result means. |
| C14 | Sitting close to TV / dim light / computers | "AAO: it can cause strain but does not damage vision." (myth 10, 11, 12) | S35 verified. Sitting close may hint at nearsightedness in kids. |
| C15 | Carrots | "Vitamin A is needed for vision but carrots won't improve it beyond normal needs." | S35 myth 4 verified. |
| C16 | Colour blindness | "Most people with colour blindness see partial colour; women can be affected though men are at higher risk. AAO's 2017 explainer gives 5-8% of males and 0.5% of females for red-green deficiency." | S35 myths 8-9 and S72 verified. **AAO's myths page says "about 1 in 10 males" while S72 says 5-8%: the two AAO pages disagree - use S72's range, attribute it, never state one number as settled.** |
| C17 | Sun gazing | "Looking at the sun can permanently damage the retina; only ISO 12312-2 solar viewers are safe." | S35 myth 6 verified. |
| C18 | ISO 8596 | "ISO 8596:2017 specifies Landolt-ring optotypes and a method for measuring distance acuity; it is neither a clinical-measurement standard nor for certifying blindness." | S42 verified (scope note). |
| C19 | Line-scoring convention | "In the 1984 ICO visual acuity standard, a line is considered read when more than 50% of its optotypes are read." | S43 verified (hosted copy). Clinical practice varies. |
| C20 | Driving thresholds | US-specific: "In most US states 20/40 or better is needed for an unrestricted licence." | S44 verified; **not applicable to Iraq** without local source. |
| C21 | Presbyopia | "Presbyopia is a normal age-related loss of near focusing as the lens becomes less flexible; it usually begins in the 40s (NEI: usually after 45; AAO: shortly after 40) and is corrected with glasses, contacts, medication or surgery. NEI classes it as a refractive error." Earlier onset is possible (farsightedness, diabetes, some medicines). | S78, S79, S80 verified. "Not a disease" must carry the caveat that blurred near vision still deserves an exam. |
| C22 | Contact lenses | "CDC: lenses are medical devices, not risk-free. Sleeping in lenses raises the risk of lens-related eye infection about six- to eightfold (US observational estimates); storing lenses in water up to sixteenfold; remove lenses before swimming/showering; replace the case at least every 3 months." | S75, S76, S77 verified. US data; professional-review flag always; state action, never fear. |
| C23 | Colour-vision plate tests | "Plate tests such as Ishihara screen for red-green deficiency; they are screening, not diagnosis; online versions cannot diagnose; plates detect ~96% of anomaloscope-confirmed cases." | S72, S73, S74 verified. |
| C24 | Blind spot | "The blind spot is the region where the optic nerve leaves the retina and has no photoreceptors (about 6 degrees across); the brain fills it in. How filling-in works is debated." Retinal damage or glaucoma gaps can also be filled in, so people may be unaware. | S69, S70, S71 verified (mechanism contested). Give exact demo geometry before publishing; do not turn into a self-test for disease. |
| C25 | Subjective refraction ("1 or 2") | "Clinicians report that patients often cannot decide which lens is clearer and tell them neither will be crystal clear; 'about the same' is an allowed answer." | S81, S82, S83 are trade-journal practitioner sources: label as practitioner evidence. Do not claim the exam 'forgives' wrong answers. |
| C26 | Astigmatism | "Astigmatism is an imperfection in the curvature of the cornea or lens, so light does not focus at one point; blur at near and far; risk is inherited; it can follow disease, injury or surgery; reading in low light or sitting close to the TV does not cause it; children may not realise they see blurry." | S84, S85, S86 verified. Do not write "mostly inherited" or "not from screens" (not stated); do not ask the viewer whether their eye has this shape. |
| C27 | Sunglasses and UV | "UV protection comes from the lens material/coating, not tint darkness or price; look for 100% UV / UV400; UV contact lenses leave the eyelid, conjunctiva and surrounding skin exposed; the AAO answer says dark lenses without UV filtering may increase exposure because pupils stay larger (no comparator stated)." | S87, S88, S89, S90 verified. Name no brands; keep 'may'. |
| C28 | Dry eye and watery eyes | "Dry or irritated eyes can produce extra tears (reflex tearing) and dryness is one of the most common causes of excessive tearing; watery eyes also arise from blocked drainage, so persistent tearing needs an exam; tears have oily, watery and mucus layers; the oily layer slows evaporation." | S91, S92, S93 verified. State as general knowledge, never as the viewer's cause. |

## D. Needs research before use (do not assert)
Dry-eye mechanisms and screen time - children's screen time and myopia causality - atropine and red-light therapy specifics (outside this project's verification) - contact-lens infection statistics - prevalence figures for Iraq - glaucoma/OCT screening claims - any "X% of people" figure not in section C - evidence on 20-20-20 efficacy - night-mode/sleep effects beyond AAO's advice - eyewear coatings/marketing claims.

## E. Wording patterns
- "According to [body, year]..." > "Science says...".
- "On average" for pooled effects; "in these trials" for RCT populations.
- "Is associated with" for observational links.
- Replace "destroys / blinds / ruins" with the specific, evidenced consequence (e.g. temporary dryness, strain).
- Add efficacy: whenever a concern is named, give a realistic action.

## F. Review checklist (copy into the claim table)
[ ] claim extracted [ ] source opened [ ] exact wording supported [ ] population/date stated [ ] verb capped [ ] no fear/diagnosis [ ] optometry/ophthalmology correct [ ] regional scope checked [ ] professional review flag decided [ ] overlay/caption text included
