# Writing hooks in natural Iraqi Arabic

**Honesty note [Guess/Likely]:** This guide is built from (a) two linguistic sources on Mesopotamian Arabic (Albuarabi 2018, S59; Ahmed 2018 thesis, S60) and (b) the model's general knowledge of Iraqi usage. No corpus of Iraqi short-video scripts was studied. The creator is the authority on what sounds natural to his audience; treat every example as a draft and let the creator veto.

## 1. Which Iraqi?
Iraqi/Mesopotamian Arabic splits into *gelet* (Bedouin-influenced; the majority of central and southern Iraq including Muslim Baghdad; qaf -> **گ**, 1st person past -**ـت**: "گلت") and *qeltu* (sedentary northern/urban non-Muslim Baghdad varieties; Mosul: qaf kept as /q/, "قلتُ") (S60). **Default here: Baghdadi/central gelet**, which most Iraqi audiences understand. Ask the creator once if he wants a regional flavour; do not mix.

## 2. Writing system
Use ordinary Arabic letters plus **گ** (g), **چ** (ch), **پ** (p) where the dialect needs them. Write the way people text: "گال", "چان", "هواية". Keep diacritics out of scripts (they slow editing); add them only where a word is ambiguous when read aloud.

## 3. Dialect markers (core, low-risk set)
| Function | Iraqi (use) | MSA / calque (avoid in hooks) |
|---|---|---|
| what / why / how / where / how much | شنو / ليش / شلون / وين / شكد | ماذا / لماذا / كيف / أين / كم |
| there is / isn't | اكو / ماكو | يوجد / لا يوجد |
| now | هسه | الآن |
| a lot / very | هواية (كثير), كلش | جداً |
| ongoing action | **دا** + present: دا أشوف | مضارع بلا جهة |
| future | **راح** + present: راح تشوف | سوف |
| negation (non-verbal) | مو: مو صحيح | ليس |
| negation (verbal) | ما: ما يضعّف | لا / لم |
| this / these | هذا / هاي / هذول | هذا/هذه/هؤلاء |
| say | يگول، گال، گلت | يقول/قال |
| see | شوف (imp.), يشوف | انظر |

Rule of thumb: **MSA is not wrong in an on-screen term; it is wrong in a spoken hook.** If a sentence needs a case ending, it is probably MSA.

## 4. Scientific terms
- Keep **English** where the audience says it that way: 20/20, Snellen, OCT (only if the video explains it), UV.
- Use common Arabic for body/optics words: العدسة، القرنية، الشبكية، البؤبؤ، الجفن، قصر النظر (myopia), طول النظر (hyperopia), فحص النظر، قياس النظر، نظارة، لنزات/عدسات لاصقة (ask the creator which his audience uses) [Likely; verify].
- Introduce a term once, with a plain gloss: `الاستجماتزم، يعني العين مو كروية تماماً.` Do not stack three terms in one sentence.
- Never translate a standards term loosely: "ISO 8596" is a test-chart/optotype standard; it is **not** a clinical measurement or certification standard (its own scope note, S42).

## 5. Sentence design
- One idea per sentence; target <= ~10-12 spoken words in the hook (a **test**, not a rule: measure it by reading aloud at natural pace).
- Start with a verb or a concrete noun, not with a preamble ("اليوم راح أحچيلكم عن…").
- Prefer the concrete subject: **الثقب**، **السطر**، **الرمش**، **عيونك**.
- Keep rhythm speakable: break at natural breath points; avoid three genitive chains.
- Numbers: write digits on screen, say the shortest spoken form. "20/20" -> "عشرين عشرين".
- Humour: dry, observational, never at the expense of a safety fact.

## 6. Anti-patterns (what to remove)
1. Generic openers: هل تعلم / سر / اسرار / لن تصدق / صدمة.
2. MSA calques: سوف، لقد، حيث أن، في هذا الفيديو سنتناول، يعتبر من أهم.
3. Literal translations of English hook formulas ("You won't believe what happens when…" -> "ما راح تصدق شنو يصير لما…").
4. Superlatives without evidence: أخطر، أعظم، الأفضل بالعالم.
5. Rhetorical questions that fit any subject.
6. The same sentence frame reused across hooks ("ليش … ؟" x10).
7. Fear verbs attached to unsupported causes: يدمّر، يعمّي، يخرّب.
8. Over-stuffed hybrids: dialect + 3 Latin terms + a statistic in 8 words.

## 7. Compare registers for one idea (myth: glasses weaken eyes; S35)
- **Formal Arabic:** `لا تؤدي النظارات إلى إضعاف العينين وفق الأكاديمية الأمريكية لطب العيون.` - accurate, lifeless, unspeakable as a hook.
- **Natural Iraqi:** `يگولون النظارة تضعّف العين. الأكاديمية الأمريكية لطب العيون تگول: لا.` - speakable, specific, attributable.
- **Hybrid scientific:** `النظارة ما تضعّف العين. بس myopia control lenses شغلة ثانية.` - useful only if the video explains the second sentence immediately.
Choose Natural Iraqi for the hook, hybrid for the explanatory beat, formal for the on-screen source line.

## 8. Rewrite drills (use when polishing)
| Draft | Problem | Rewrite |
|---|---|---|
| `سوف نتعرف اليوم على سر الرؤية الواضحة` | MSA, generic, "سر" | `ثقب صغير بورقة… والمشوّش يصير واضح.` |
| `هل تعلم أن الشاشات تضر بعينيك؟` | generic opener, unsupported fear | `عيونك تحترق بعد ساعة ريلز؟ تغمّض أقل من المعتاد.` |
| `أخطر عادة تدمر عينك` | superlative + fear | `عادة صغيرة تتعب عيونك يومياً… وعلاجها ٢٠ ثانية.` (needs 20-20-20 wording check) |

## 8b. Vocabulary flags from Phase-2 testing (Guess-level; the creator confirms)
| Used in a draft | Concern | Safer candidate (confirm) |
|---|---|---|
| تغمّض (for blinking) | means "close the eyes"; blink is probably **ترمش / رمش** | `ترمش أقل` |
| قبل لا (before) | likely not Iraqi | `گبل ما` |
| أضعاف | formal | `مرات` / `ضعف` |
| يعتبر | formal | `ينحسب` / `يعدّونه` |
| إجهاد العين | formal | `تعب العين` |
| صفحة الألوان / ورقة (sticker) | odd | `لوحة الألوان` / `الملصق` |
| تتعطل / تدمّر for gradual change | overdramatic and inaccurate | `تصير أقل مرونة` |
| ممنوع | stronger than most medical sources | `يُنصح بإزالتها` -> `الأفضل تشيلها` |
Keep a confirmed-terms list per creator; until he confirms, mark these words in the output.

## 9. Checks the model can and cannot do
Can: spot MSA markers, generic phrases, repeated frames, over-length. Cannot: guarantee natural pronunciation or regional acceptability -> always flag "needs native review".
