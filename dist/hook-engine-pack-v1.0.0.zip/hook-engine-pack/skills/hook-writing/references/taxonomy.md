# Hook taxonomy - 24 mechanisms

Families: **C** Claim - **Q** Question - **V** Visual/Device - **N** Narrative - **E** Evidence - **S** Sensory/Structure.
Evidence status: mechanism effectiveness is **Guess/Likely** unless noted; lab support exists for the *psychology* behind several (see curiosity-psychology.md) but no mechanism here has been validated on 20-45 s feeds. Examples are Iraqi Arabic drafts; facts marked ✔ have a source in the ledger (AAO 20/20 S44, AAO myths S35, AAO digital devices S32/S33, pinhole S45/S46, spectacle myopia lenses S39, outdoor time S40); everything else is **placeholder - verify before use**.

Columns per entry: Mechanism - why it can work - fits when - fails when - ethics/factual limits - weak / improved / strong - optics fit - combines with.

---
### Claim family
**M01 Counterintuitive fact** - Violates a held belief (prediction error). Fits: a fact is surprising AND verified. Fails: surprise is trivia with no consequence. Limits: cite; no overstated scope. Weak `العين شي عجيب.` / Improved `20/20 مو نظر مثالي.` / Strong `20/20 مو يعني نظرك ممتاز… يعني نظرك عادي. وهواية ناس أحسن منك.` ✔S44. Optics: high. Combines: V01 chart demo, E01.

**M02 Misconception / myth correction** - Names a common belief then corrects it. Fits: belief is widespread locally. Fails: you repeat the myth so often it sticks; correction is partial. Limits: scope the correction (glasses vs myopia-control lenses). Weak `خرافات عن العين.` / Improved `النظارة تضعّف العين؟ لا.` / Strong `يگولون: لبست نظارة، عيونك راح تتعوّد وتضعف. شنو يگول البحث؟` ✔S35 myth 14. Optics: very high. Combines: E01, N02.

**M03 Unexpected consequence** - A small cause with a surprising effect. Fits: causal chain is documented. Fails: consequence exaggerated into fear. Limits: no "X causes disease" without evidence. Weak `الشاشة تأذي عيونك.` / Improved `ساعة ريلز تخلي رمشك أقل.` / Strong `شنو يصير لرمشك وانت تتفرج ريلز؟ ينزل من حوالي ١٥ للدقيقة لـ ٥-٧ حسب دراسات AAO.` ✔S32 (verify wording "studies show"). Optics: high.

**M04 Contradiction / paradox** - Two true things that seem incompatible. Fits: real paradox. Fails: paradox is wordplay. Limits: both halves sourced. Weak `العين تشوف وما تشوف.` / Strong `بكل عين عندك نقطة عمياء… ومع هذا ما تلاحظها.` (blind spot; verify before use). Optics: high.

**M05 Hidden mechanism** - "Why X works / what's behind it." Fits: mechanism is visible or animatable. Fails: mechanism needs 2 min. Weak `كيف تشتغل العدسة؟` / Strong `ليش ثقب صغير يخلي المشوّش يصير حاد؟` ✔S45,S46. Optics: very high.

**M06 Surprising comparison** - Maps the unfamiliar onto the familiar. Fits: analogy is accurate. Fails: analogy misleads (camera=eye over-extended). Limits: state where the analogy breaks. Weak `العين مثل الكاميرا.` / Strong `نفس خدعة الثقب بالكاميرا القديمة… بس بعينك.` (pinhole camera analogy; verify). Optics: high.

**M07 Specific stakes / practical relevance** - "This changes what you do tomorrow." Fits: concrete action with evidence. Fails: stakes inflated. Limits: no fear; include efficacy. Weak `لازم تهتم بعيونك.` / Strong `بعد ساعة شاشة، ثبّت عيونك بشي بعيد ٢٠ ثانية. يمكن تحس الفرق.` ✔S33 (20-20-20 is AAO advice; individual benefit not guaranteed -> "يمكن"). Optics: high.

### Question family
**M08 Curiosity question** - Specific, answerable question. Fits: viewer half-knows the topic. Fails: generic/rhetorical. Weak `هل تعلم كيف نشوف؟` / Strong `شنو يعني الرقم الثاني بـ 20/20؟` ✔S44.

**M09 Diagnostic self-recognition (no diagnosis)** - "Ever notice X?" Viewer recognises an everyday experience. Fits: common, benign, explained. Fails: drifts into symptom-checking. Limits: never name a disease from a symptom; add "see an eye professional if persistent". Weak `عندك مشكلة بنظرك؟` / Strong `تشوف هالات حول الأضواء بالليل؟ هالشي يصير لأسباب بصرية عادية كثيرة… وشنو الي لازم ينتبه له الواحد.` (needs clinical review before use). Optics: medium; **flag for professional review**.

**M10 Prediction and test** - Asks the viewer to guess, then tests. Fits: outcome is visible. Fails: result ambiguous. Weak `خمّن شنو يصير.` / Strong `شنو تتوقع يصير للسطر المشوّش إذا شفته من ثقب؟ جرّب.` ✔S45. Optics: very high.

### Visual/Device family
**M11 Demonstration / visual reveal** - Shows the effect before explaining. Fits: effect is legible in frame 1-2 s. Fails: camera cannot show what the eye sees (see hook-visual-design). Strong: blurred text -> pinhole card enters -> text sharp.

**M12 Before/after contrast** - Same subject, two states. Fits: honest comparison, same conditions. Fails: lighting/exposure changes fake the difference. Limits: control camera settings; label simulations.

**M13 Object/device-led** - Opens on a specific instrument (phoropter, lensmeter, trial frame). Fits: object itself raises a question. Fails: object is a prop. Weak `هذا جهاز فحص النظر.` / Strong `هالجهاز يسألك "هذي لو هذي؟" مرات هواية. شنو ورا هالأسئلة؟` (phoropter A/B comparisons; verify wording).

**M14 Unusual experiment** - Home or studio experiment with clear outcome. Fits: safe, reproducible. Limits: no unsafe eye experiments (no sun gazing, lasers, chemicals; AAO myth 6).

### Narrative family
**M15 Micro-story** - Begin inside a moment of tension. Fits: story is true or labelled composite. Fails: invented patient anecdotes. Limits: privacy; no fabricated cases.

**M16 Challenge to assumption** - "You've been taught X; look at the evidence." Overlaps M02; use when authority/tradition is the target.

**M17 Personal-experience opener** - Creator's own measured experiment. Fits: creator really did it. Limits: never claim an experience that did not occur.

### Evidence family
**M18 Evidence-led revelation** - Opens with the data/figure. Fits: one clean number. Weak `دراسات تثبت.` / Strong `٢٣ تجربة عشوائية، ١٣ ألف طفل: عدسات معينة تبطّئ تقدّم قصر النظر.` ✔S39 (average effect: -0.31 D SER; specify "average"). Fails: number without meaning. Limits: study type sets the verb.

**M19 Immediate payoff then deeper explanation** - Gives the answer in 3 s, spends the video on the why. Fits: answer is simple, mechanism is the value. Fails: nothing left to learn. Test the "got what they came for" drop (S50).

### Structure/Sensory family
**M20 Open loop** - Names something you will reveal. Fits: loop is closed in <= duration. Fails: closed too late or never; needless withholding. One primary loop only.

**M21 Sound-led** - A sound that is itself the question (e.g. click of trial lenses). Fits: sound semantics clear. Fails: sound as decoration. Must still pass sound-off test via text.

**M22 Motion-led** - Movement in frame 1 asks the question (object enters, focus pulls). Fits: motion is meaningful.

**M23 Hybrid verbal + visual** - Voice and image complete each other (voice asks, image shows). Strongest default for 20-45 s optics [Likely, design judgement].

**M24 Series/context hook** - "Part 2 / answering a comment." Fits: genuinely sequential content. Fails: part 1 is not self-contained.

---
## Combination rule
Max two mechanisms per hook (one primary + one supporting). More = clutter. Typical strong pairs: M02+M11, M05+M11, M18+M19, M08+M23.

## What to avoid across all mechanisms
Generic openers, superlatives without evidence, fear framing, unverifiable "doctors don't want you to know", cliffhangers that the script does not close, and mechanisms chosen because they are fashionable rather than because the idea fits.
